// সিনের সময়-পরিসর (সেকেন্ড, গ্লোবাল) — ভয়েসের cue থেকে
import { cs, at } from "./cues";

const tTahole = at(22, "তাহলে") - 0.6;

const tBut = at(16, "কিন্তু") - 0.2;
export const SC = {
  A: [0, cs(3) - 0.15],
  B: [cs(3) - 0.15, cs(6) - 0.45],
  C: [cs(6) - 0.45, cs(7) - 0.3],
  D: [cs(7) - 0.3, cs(13) - 0.3],
  E: [cs(13) - 0.3, tBut],
  F: [tBut, cs(18) - 0.2],
  G: [cs(18) - 0.2, cs(21) - 0.2],
  H: [cs(21) - 0.2, tTahole],
  I: [tTahole, cs(23) - 0.3],
  J: [cs(23) - 0.3, 121],
} as const;
