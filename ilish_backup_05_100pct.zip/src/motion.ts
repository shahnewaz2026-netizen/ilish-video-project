import { spring, Easing } from "remotion";

export const FPS = 30;
// মেজাজ: তথ্যভিত্তিক-শান্ত → ওভারশুট কম
export const SPRING = {
  pop: { damping: 16, stiffness: 150, mass: 0.85 },
  soft: { damping: 24, stiffness: 110, mass: 1 },
  lively: { damping: 13, stiffness: 160, mass: 0.8 },
};
export const clamp01 = (x: number) => Math.min(1, Math.max(0, x));
export const easeIO = Easing.bezier(0.45, 0, 0.2, 1);
export const easeOut = Easing.bezier(0.16, 1, 0.3, 1);
export const lerp = (a: number, b: number, p: number) => a + (b - a) * p;

export const clock = (f: number) => {
  const t = f / FPS;
  return {
    f, t,
    pop: (at: number, cfg = SPRING.pop) => spring({ frame: f - Math.round(at * FPS), fps: FPS, config: cfg }),
    seg: (a: number, b: number, e: (x: number) => number = easeIO) => e(clamp01((t - a) / (b - a))),
    on: (a: number) => (t >= a ? 1 : 0),
  };
};
export type Clock = ReturnType<typeof clock>;
