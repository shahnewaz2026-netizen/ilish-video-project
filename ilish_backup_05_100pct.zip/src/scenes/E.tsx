import React from "react";
import { useCurrentFrame, interpolateColors } from "remotion";
import { theme as T, FONT } from "../theme";
import { clock, lerp, easeOut, easeIO } from "../motion";
import { at, cs } from "../cues";
import { Hilsa, Pearls, Net, G, Idle, Drop, Star } from "../art";
import { Chip, XMark, Stamp, Arrow } from "../components/ui";

const JATKA: [number, number, number][] = [[-180, -40, 0], [-70, 40, 1.2], [60, -60, 2.1], [170, 20, 3], [10, 90, 4.2]];

// সিন E: ধাপ ২ — বাচ্চা বাঁচানো (জাটকা)
export const SceneE: React.FC = () => {
  const C = clock(useCurrentFrame());
  const vis = (a: number, b: number, f = 0.45) => C.seg(a, a + f) * (1 - C.seg(b, b + f));

  const tEgg = at(13, "ডিম"), tBaby = at(13, "বাচ্চা"), tWhat = at(13, "কী");
  const tJ = at(14, "জাটকা", 0), tCatch = at(14, "ধরলে");
  const tBig = at(15, "বড়", 0), tEggs2 = at(15, "ডিমও"), tYear = at(15, "বছরের"), tTime = at(15, "সময়"), tBan = at(15, "বন্ধ"), tRes = at(15, "গবেষকদের");
  const tOil = at(16, "তেল"), tTaste = at(16, "স্বাদও");

  // ১. মা → ডিম → বাচ্চা
  const v1 = vis(cs(13) - 0.1, tJ - 0.2);
  const hatch = C.seg(tBaby, tBaby + 0.8);
  // ২. জাটকা ঝাঁক
  const v2 = vis(tJ - 0.2, tBig - 0.1);
  const netY = lerp(80, 520, C.seg(tCatch, tCatch + 0.9, easeOut));
  // ৩. বড় হয় না / ডিম দেয় না
  const v3 = vis(tBig - 0.1, tYear - 0.2);
  // ৪. বছরের চক্র
  const v4 = vis(tYear - 0.2, tRes - 0.1);
  // ৫. বড় হলে তেল ও স্বাদ
  const v5 = vis(tRes - 0.1, 999);
  const grow = C.seg(tRes, tRes + 1.2, easeIO);

  return (
    <g>
      {/* ১ */}
      {v1 > 0.01 && (
        <g opacity={v1}>
          <G x={430} y={440} s={1.2 * C.pop(cs(13))}><Idle amp={4} speed={2.2} rot={2}><Hilsa eggs wobble={2} /></Idle></G>
          <Arrow x1={620} y1={470} x2={780} y2={560} p={C.seg(tEgg, tEgg + 0.4)} />
          <g opacity={1 - hatch}><Pearls pts={Array.from({ length: 9 }, (_, i) => [900 + (i % 5) * 34, 600 + Math.floor(i / 5) * 30] as [number, number])} r={11} o={C.seg(tEgg, tEgg + 0.5)} /></g>
          {JATKA.map(([x, y, ph], i) => (
            <G key={i} x={1000 + x * 0.7} y={560 + y * 0.8} s={0.38 * C.pop(tBaby + 0.1 + i * 0.1)} o={hatch}>
              <Idle amp={4} speed={3} ph={ph} rot={4}><Hilsa wobble={4} /></Idle>
            </G>
          ))}
          <Chip x={900} y={730} text="ডিম" p={C.pop(tEgg)} tone={T.warn} />
          <Chip x={1180} y={730} text="বাচ্চা" p={C.pop(tBaby)} tone={T.good} />
          {C.t >= tWhat && (
            <g opacity={C.seg(tWhat, tWhat + 0.25)}>
              <circle cx={1500} cy={440} r={56} fill={T.surface} stroke={T.warn} strokeWidth={5} />
              <text x={1500} y={462} textAnchor="middle" fontFamily={FONT} fontWeight={700} fontSize={76} fill={T.warn}>?</text>
            </g>
          )}
        </g>
      )}

      {/* ২ */}
      {v2 > 0.01 && (
        <g opacity={v2}>
          {JATKA.map(([x, y, ph], i) => (
            <G key={i} x={960 + x * 1.15} y={520 + y * 1.1} s={0.62 * C.pop(cs(14) + 0.05 * i)}>
              <Idle amp={5} speed={3} ph={ph} rot={4}><Hilsa wobble={4} /></Idle>
            </G>
          ))}
          <Chip x={960} y={310} text="জাটকা" p={C.pop(tJ)} tone={T.accent} solid size={42} />
          {C.t >= tCatch && (<g opacity={1}>
            <G x={960} y={netY}><Net rx={380} ry={210} fill={0.14} /></G>
          </g>)}
        </g>
      )}

      {/* ৩ */}
      {v3 > 0.01 && (
        <g opacity={v3}>
          <G x={420} y={560} s={0.8 * C.pop(tBig - 0.1)}><Idle amp={3} speed={2.6} rot={3}><Hilsa wobble={3} /></Idle></G>
          <Chip x={420} y={440} text="জাটকা" p={C.pop(tBig - 0.1)} tone={T.accent} />
          <Arrow x1={560} y1={560} x2={760} y2={560} p={C.seg(tBig, tBig + 0.4)} />
          <G x={1020} y={560} s={1.25 * C.pop(tBig + 0.2)}><Hilsa ghost={0.8} /></G>
          <XMark x={1020} y={560} size={64} p={C.seg(at(15, "না", 0) - 0.2, at(15, "না", 0) + 0.3)} />
          <Chip x={1020} y={720} text="বড় হয় না" p={C.pop(tBig + 0.3)} tone={T.bad} />
          <G x={1600} y={570} s={C.pop(tEggs2)} o={0.9}><Pearls pts={[[-40, -20], [0, -26], [40, -18], [-20, 18], [20, 14]]} r={13} /></G>
          <g opacity={0.5 * C.pop(tEggs2)}><circle cx={1600} cy={570} r={86} fill="none" stroke={T.muted} strokeWidth={4} strokeDasharray="10 10" /></g>
          <XMark x={1600} y={570} size={56} p={C.seg(at(15, "না", 1) - 0.2, at(15, "না", 1) + 0.3)} />
          <Chip x={1600} y={720} text="ডিম দেয় না" p={C.pop(tEggs2)} tone={T.bad} />
        </g>
      )}

      {/* ৪ বছরের চক্র */}
      {v4 > 0.01 && (
        <g opacity={v4}>
          <g transform="translate(960 500)">
            {Array.from({ length: 12 }, (_, i) => {
              const a0 = (i / 12) * Math.PI * 2 - Math.PI / 2 + 0.03, a1 = ((i + 1) / 12) * Math.PI * 2 - Math.PI / 2 - 0.03;
              const R = 230, r = 150;
              const closed = i < 9;
              const p = closed ? C.seg(lerp(tYear, tTime, i / 9), lerp(tYear, tTime, i / 9) + 0.35) : 1;
              const fill = interpolateColors(p, [0, 1], [T.good, closed ? T.bad : T.good]);
              const pt = (rr: number, a: number) => `${Math.cos(a) * rr} ${Math.sin(a) * rr}`;
              return <path key={i} d={`M ${pt(R, a0)} A ${R} ${R} 0 0 1 ${pt(R, a1)} L ${pt(r, a1)} A ${r} ${r} 0 0 0 ${pt(r, a0)} Z`} fill={fill} stroke={T.line} strokeWidth={3} opacity={C.pop(tYear - 0.2 + i * 0.02)} />;
            })}
            <G s={0.7}><Idle amp={3} speed={2.6} rot={3}><Hilsa wobble={3} /></Idle></G>
          </g>
          <Chip x={960} y={236} text="বছরের বড় একটা সময়" p={C.pop(tYear)} tone={T.accent} />
          <Stamp x={1400} y={500} text="জাটকা ধরা বন্ধ" p={C.seg(tBan, tBan + 0.35)} size={44} />
        </g>
      )}

      {/* ৫ বড় ইলিশ: তেল ও স্বাদ */}
      {v5 > 0.01 && (
        <g opacity={v5}>
          <G x={960} y={520} s={lerp(0.7, 1.7, grow)}><Idle amp={4} speed={2.2} rot={2}><Hilsa glow={grow > 0.9} wobble={2} /></Idle></G>
          {[[760, 360], [1000, 330], [1180, 400], [880, 700]].map(([x, y], i) => (
            <G key={i} x={x} y={y} s={C.pop(tOil + i * 0.12)}><Idle amp={5} speed={2.4} ph={i}><Drop /></Idle></G>
          ))}
          <Chip x={820} y={250} text="তেল বেশি" p={C.pop(tOil)} tone={T.warn} size={40} />
          {[1330, 1400, 1470].map((x, i) => <G key={i} x={x} y={420} s={1.2 * C.pop(tTaste + i * 0.15)}><Star /></G>)}
          <Chip x={1400} y={520} text="স্বাদও বেশি" p={C.pop(tTaste)} tone={T.warn} size={40} />
        </g>
      )}
    </g>
  );
};
