import React from "react";
import { useCurrentFrame } from "remotion";
import { theme as T } from "../theme";
import { clock, lerp, easeIO } from "../motion";
import { at, cs } from "../cues";
import { Hilsa, Water, Pearls, G, Idle, Drop } from "../art";
import { Chip } from "../components/ui";

// সিন B: সমুদ্র → নদী, অতিথি, ডিম পাড়তে আসা
export const SceneB: React.FC = () => {
  const C = clock(useCurrentFrame());
  const WL = 400, SEA = [100, 940], RIV = [940, 1820];
  const tSea = at(3, "সমুদ্রে"), tTravel = at(3, "এখানে"), tGuest = at(3, "অতিথি"), tWhy = at(3, "কেন");
  const tEgg = at(4, "ডিম"), tSeaFish = at(5, "ইলিশ"), tFresh = at(5, "মিঠা");

  const pT = C.seg(tTravel, tWhy + 0.3, easeIO);
  const fx = lerp(380, 1330, pT), fy = lerp(640, 600, pT) + Math.sin(C.t * 3) * 6;
  const eggT = (i: number) => tEgg + 0.15 + i * 0.12;
  const pts: [number, number][] = Array.from({ length: 9 }, (_, i) => [1160 + (i % 5) * 40 + (Math.floor(i / 5) ? 20 : 0), 780 + Math.floor(i / 5) * 28]);
  const trail = Array.from({ length: 10 }, (_, i) => ({ x: lerp(380, fx, i / 10), y: lerp(640, fy, i / 10), o: C.seg(tTravel, tTravel + 0.3) * (i / 10) * 0.8 }));

  return (
    <g>
      <Water x0={SEA[0]} x1={SEA[1]} y0={WL} y1={850} fill={T.sea} deep={T.seaDeep} amp={9} />
      <Water x0={RIV[0]} x1={RIV[1]} y0={WL} y1={850} fill={T.river} deep={T.riverDeep} amp={5} speed={0.7} />
      <line x1={940} y1={WL} x2={940} y2={850} stroke={T.fishHi} strokeWidth={3} strokeDasharray="10 12" opacity={0.3} />

      <Chip x={520} y={310} text="সমুদ্র" p={C.pop(tSea)} tone={T.data} size={40} />
      <Chip x={1380} y={310} text="নদী" p={C.pop(tSea + 0.4)} tone={T.flow} size={40} />

      {/* ভ্রমণ-পথের ডট */}
      {trail.map((d, i) => <circle key={i} cx={d.x} cy={d.y} r={7} fill={T.flow} opacity={d.o} />)}

      {/* অতিথি ইলিশ */}
      <G x={fx} y={fy} s={C.pop(cs(3) - 0.2) * 1.05}>
        <Idle amp={3} speed={3} rot={2}><Hilsa wobble={3} /></Idle>
      </G>
      <Chip x={fx} y={fy - 120} text="অতিথি" p={C.pop(tGuest)} tone={T.accent} solid />
      {C.t >= tWhy && C.t < tEgg + 0.2 && (
        <g opacity={C.seg(tWhy, tWhy + 0.2)}>
          <circle cx={fx + 90} cy={fy - 80} r={34} fill={T.surface} stroke={T.warn} strokeWidth={4} />
          <text x={fx + 90} y={fy - 66} textAnchor="middle" fontFamily="HindSiliguri" fontWeight={700} fontSize={46} fill={T.warn}>?</text>
        </g>
      )}

      {/* ডিম */}
      {pts.map((p, i) => {
        const q = C.seg(eggT(i), eggT(i) + 0.7);
        return q > 0 ? <Pearls key={i} pts={[[p[0], lerp(fy + 30, p[1], q)]]} r={9} o={q} /> : null;
      })}
      <Chip x={1330} y={720} text="ডিম পাড়তে" p={C.pop(tEgg)} tone={T.warn} />

      {/* সমুদ্রের মাছ */}
      <G x={380} y={640} s={C.pop(tSeaFish) * 0.9} o={C.pop(tSeaFish)}><Idle amp={4} speed={2.4} rot={2}><Hilsa wobble={3} /></Idle></G>
      <Chip x={380} y={540} text="সমুদ্রের মাছ" p={C.pop(at(5, "সমুদ্রের"))} tone={T.data} />
      <G x={1560} y={470} s={C.pop(tFresh)}><Drop fill={T.good} /></G>
      <Chip x={1560} y={560} text="মিঠা পানি" p={C.pop(tFresh)} tone={T.good} />
    </g>
  );
};
