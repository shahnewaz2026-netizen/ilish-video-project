import React from "react";
import { useCurrentFrame, interpolateColors } from "remotion";
import { theme as T, FONT } from "../theme";
import { clock } from "../motion";
import { at } from "../cues";
import { Hilsa, Water, G, Idle } from "../art";
import { Chip, Check } from "../components/ui";

// সিন F: মা-বাচ্চা বাঁচল, কিন্তু নদী যদি বদলে যায়?
export const SceneF: React.FC = () => {
  const C = clock(useCurrentFrame());
  const tBut = at(16, "কিন্তু"), tSaved = at(16, "বাঁচালেও"), tRiver = at(17, "নদী"), tChange = at(17, "বদলে");
  const mix = C.seg(tChange, tChange + 1.4);
  const wf = interpolateColors(mix, [0, 1], [T.river, "#7A8A5C"]);
  const wd = interpolateColors(mix, [0, 1], [T.riverDeep, "#5E6E46"]);
  return (
    <g>
      <G x={420} y={470} s={1.2 * C.pop(tBut)}><Idle amp={4} speed={2.2} rot={2}><Hilsa eggs wobble={2} /></Idle></G>
      <G x={720} y={560} s={0.6 * C.pop(tBut + 0.3)}><Idle amp={4} speed={3} ph={1} rot={3}><Hilsa wobble={3} /></Idle></G>
      <Check x={570} y={330} size={50} p={C.seg(tSaved, tSaved + 0.5)} />
      <Chip x={570} y={700} text="মা আর বাচ্চা" p={C.pop(tBut)} tone={T.good} />

      <Water x0={1000} x1={1820} y0={420} y1={850} fill={wf} deep={wd} amp={7} />
      <Chip x={1410} y={330} text="নদী" p={C.pop(tRiver)} tone={T.flow} size={42} />
      {mix > 0 && Array.from({ length: 14 }, (_, i) => (
        <circle key={i} cx={1040 + ((i * 97) % 740)} cy={470 + ((i * 53) % 340)} r={6} fill={T.salt} opacity={mix * 0.85} />
      ))}
      {C.t >= tChange && (
        <g opacity={C.seg(tChange + 0.8, tChange + 1.2)}>
          <circle cx={1410} cy={630} r={60} fill={T.surface} stroke={T.warn} strokeWidth={5} />
          <text x={1410} y={656} textAnchor="middle" fontFamily={FONT} fontWeight={700} fontSize={84} fill={T.warn}>?</text>
        </g>
      )}
    </g>
  );
};
