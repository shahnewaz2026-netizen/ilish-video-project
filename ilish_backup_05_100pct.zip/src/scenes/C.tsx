import React from "react";
import { useCurrentFrame } from "remotion";
import { theme as T, FONT } from "../theme";
import { clock, SPRING } from "../motion";
import { at, cs } from "../cues";
import { Hilsa, Water, G, Idle } from "../art";
import { Chip, Badge } from "../components/ui";

// সিন C: তিন ধাপের ওভারভিউ কার্ড
export const SceneC: React.FC = () => {
  const C = clock(useCurrentFrame());
  const tGuest = cs(6), tThree = at(6, "তিন");
  const times = [at(6, "মা"), at(6, "বাচ্চা"), at(6, "নদী")];
  const xs = [360, 960, 1560], titles = ["মা বাঁচানো", "বাচ্চা বাঁচানো", "নদী বাঁচানো"];
  const slot = C.pop(tThree);
  const guestY = 470 - 190 * C.seg(tThree - 0.3, tThree + 0.7);
  const guestS = 1.3 - 0.55 * C.seg(tThree - 0.3, tThree + 0.7);
  return (
    <g>
      <G x={960} y={guestY} s={guestS * C.pop(tGuest)}><Idle amp={4} speed={2.2} rot={2}><Hilsa wobble={3} /></Idle></G>
      <Chip x={960} y={guestY - 80 * guestS - 34} text="অতিথি" p={C.pop(tGuest + 0.2)} tone={T.accent} solid />
      {xs.map((x, i) => {
        const p = C.pop(times[i], SPRING.soft), ph = C.pop(tThree + i * 0.12);
        const op = Math.max(p, ph * 0.28);
        return (
          <g key={i} transform={`translate(${x} ${580 + (1 - Math.max(p, ph)) * 40})`} opacity={op}>
            <rect x={-250} y={-210} width={500} height={420} rx={28} fill={T.surface} stroke={p > 0.5 ? T.accent : T.border} strokeWidth={p > 0.5 ? 4 : 2} style={{ filter: p > 0.5 ? `drop-shadow(0 0 18px ${T.accent}55)` : "none" }} />
            <Badge x={-200} y={-160} n={["১", "২", "৩"][i]} p={p} />
            {i === 0 && <G y={-10} s={1.0 * p}><Idle amp={3} speed={2.2} rot={2}><Hilsa eggs wobble={2} /></Idle></G>}
            {i === 1 && (<g>
              <G x={-70} y={-40} s={0.55 * p}><Idle amp={3} speed={2.6} ph={0.5} rot={3}><Hilsa wobble={3} /></Idle></G>
              <G x={60} y={-90} s={0.45 * p}><Idle amp={3} speed={2.2} ph={1.5} rot={3}><Hilsa wobble={3} /></Idle></G>
              <G x={20} y={30} s={0.4 * p}><Idle amp={3} speed={2.8} ph={2.5} rot={3}><Hilsa wobble={3} /></Idle></G>
            </g>)}
            {i === 2 && (<g>
              <Water x0={-200} x1={200} y0={-70} y1={50} fill={T.river} deep={T.riverDeep} amp={6} />
              <G x={-20} y={-10} s={0.45 * p}><Idle amp={3} speed={2.2} rot={2}><Hilsa wobble={3} /></Idle></G>
            </g>)}
            <text x={0} y={150} textAnchor="middle" fontFamily={FONT} fontWeight={700} fontSize={46} fill={T.text}>{titles[i]}</text>
          </g>
        );
      })}
    </g>
  );
};
