import React from "react";
import { useCurrentFrame } from "remotion";
import { theme as T, FONT } from "../theme";
import { clock, lerp, easeIO } from "../motion";
import { at, cs } from "../cues";
import { Hilsa, Water, G, Idle } from "../art";
import { Chip, XMark } from "../components/ui";

// সিন H: ইলিশ একই নদীতে ফেরে; জায়গা না পেলে আর বেছে নেবে না
export const SceneH: React.FC = () => {
  const C = clock(useCurrentFrame());
  const WL = 400;
  const tSame = at(21, "একই"), tBack = at(21, "ফেরে"), tAgain = at(21, "বারবার"), tNoSpace = at(21, "জায়গা"), tChoose = at(22, "বেছে");

  // মাছ: সমুদ্র(বাঁ)→ নদী(ডান) যাত্রা, ফেরা; জায়গা না পেলে উল্টে ফেরে
  const toRiver = C.seg(cs(21), tBack, easeIO);
  const bounce = C.seg(tAgain, tNoSpace + 0.6, easeIO);
  const leave = C.seg(tChoose - 0.6, tChoose + 1.6, easeIO);
  let x = lerp(380, 1250, toRiver);
  x = x - 140 * Math.sin(bounce * Math.PI) * (C.t < tChoose - 0.6 ? 1 : 0);
  x = C.t >= tChoose - 0.6 ? lerp(1200, 360, leave) : x;
  const flip = C.t >= tChoose - 0.6;
  const y = 600 + Math.sin(C.t * 3) * 8;
  const saltOp = C.seg(tAgain, tAgain + 0.8);

  return (
    <g>
      <Water x0={100} x1={940} y0={WL} y1={850} fill={T.sea} deep={T.seaDeep} amp={9} />
      <Water x0={940} x1={1820} y0={WL} y1={850} fill={T.river} deep={T.riverDeep} amp={5} speed={0.7} />
      <line x1={940} y1={WL} x2={940} y2={850} stroke={T.fishHi} strokeWidth={3} strokeDasharray="10 12" opacity={0.3} />
      <Chip x={520} y={310} text="সমুদ্র" p={1} tone={T.data} size={38} />
      <Chip x={1380} y={310} text="একই নদী" p={C.pop(tSame)} tone={T.flow} size={40} />
      {/* ঘর-চিহ্ন (নদী) */}
      <g opacity={C.pop(tSame)}>
        <path d="M 1480 560 L 1540 505 L 1600 560 L 1600 640 L 1480 640 Z" fill="none" stroke={T.flow} strokeWidth={5} strokeLinejoin="round" strokeDasharray="14 10" opacity={0.7} />
      </g>
      {/* নোনা কণা */}
      {Array.from({ length: 16 }, (_, i) => <circle key={i} cx={1000 + ((i * 113) % 780)} cy={470 + ((i * 59) % 320)} r={7} fill={T.salt} opacity={saltOp * 0.85} />)}
      {/* ইলিশ */}
      <G x={x} y={y} s={1.05 * C.pop(cs(21))} fx={flip}><Idle amp={2} speed={3} rot={2}><Hilsa wobble={3} /></Idle></G>
      <Chip x={x} y={y - 120} text="অতিথি" p={C.pop(cs(21) + 0.2)} tone={T.accent} solid size={30} />
      {/* জায়গা না পেলে ✕ */}
      {C.t >= tNoSpace && C.t < tChoose + 0.5 && <XMark x={1480} y={470} size={46} p={C.seg(tNoSpace, tNoSpace + 0.5)} />}
      {C.t >= tChoose && (
        <g opacity={C.seg(tChoose, tChoose + 0.4)}>
          <circle cx={900} cy={510} r={52} fill={T.surface} stroke={T.warn} strokeWidth={5} />
          <text x={900} y={532} textAnchor="middle" fontFamily={FONT} fontWeight={700} fontSize={72} fill={T.warn}>?</text>
        </g>
      )}
    </g>
  );
};
