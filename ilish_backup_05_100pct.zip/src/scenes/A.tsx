import React from "react";
import { useCurrentFrame } from "remotion";
import { theme as T } from "../theme";
import { clock, lerp, easeOut, easeIO } from "../motion";
import { at, cs } from "../cues";
import { Hilsa, Person, Boat, Net, Water, Bank, Pier, Basket, Sun, Cloud, G, Idle } from "../art";
import { Chip, XMark } from "../components/ui";

// সিন A: চাঁদপুরের ঘাট, জালে রুপালি ইলিশ, "এই নদীর বাসিন্দা না"
export const SceneA: React.FC = () => {
  const C = clock(useCurrentFrame());
  const WL = 600;
  const tPerson = cs(1), tGhat = at(1, "চাঁদপুরের"), tBoat = at(1, "ঘাটে");
  const tNet = cs(2), tHighlight = at(2, "ইলিশ", 1);

  // নৌকা ঢোকে ডান থেকে
  const bx = lerp(2250, 1220, C.seg(tBoat - 0.2, tBoat + 1.6, easeOut));
  const moving = C.t > tBoat - 0.2 && C.t < tBoat + 1.6 ? 1 : 0;
  // জাল ওঠে
  const lift = C.seg(tNet, tNet + 1.1);
  const netY = lerp(WL + 30, 470, lift);
  const fishOut = [0, 1, 2, 3, 4, 5].map((i) => {
    const s = tNet + 1.0 + i * 0.32, p = C.seg(s, s + 0.8);
    const x0 = bx - 40, y0 = 470, x1 = bx - 80 + i * 24, y1 = WL - 80;
    return { p, x: lerp(x0, x1, p), y: lerp(y0, y1, p) - Math.sin(p * Math.PI) * 120, r: lerp(-30, 40, p), landed: p >= 1 };
  });
  const landed = fishOut.filter((f) => f.landed).length;
  const hiP = C.pop(tHighlight);
  const dim = 1 - 0.5 * C.seg(tHighlight, tHighlight + 0.5);

  return (
    <g>
      <G x={1560} y={270} o={C.seg(0.2, 1.2)}><Sun /></G>
      <G x={420} y={250} o={C.seg(0.4, 1.4)}><Idle amp={4} speed={0.8}><Cloud /></Idle></G>
      <G x={1000} y={210} o={C.seg(0.6, 1.6)}><Idle amp={5} speed={0.7} ph={2}><Cloud o={0.35} /></Idle></G>

      <g opacity={dim}>
        <Water x0={480} x1={1820} y0={WL} y1={850} fill={T.river} deep={T.riverDeep} />
        <Bank x0={100} x1={540} y={WL + 24} h={226} />
        <Pier x0={380} x1={640} y={WL - 6} />
      </g>

      {/* মানুষ ঘাটে */}
      <G x={470} y={WL - 22} s={C.pop(tPerson, { damping: 15, stiffness: 150, mass: 0.8 })} o={C.pop(tPerson)}>
        <Idle amp={2} speed={2}><Person pose="point" /></Idle>
      </G>
      <Chip x={300} y={330} text="চাঁদপুরের ঘাট" p={C.pop(tGhat)} />

      {/* নৌকা + জাল */}
      <g opacity={dim}>
        <G x={bx} y={WL + Math.sin(C.t * 10) * 3 * moving} r={Math.sin(C.t * 10) * 0.8 * moving}>
          <Idle amp={3} speed={1.6} rot={1}><Boat />
            <G x={-40} y={-46}><Basket fish={Math.min(5, landed)} /></G>
          </Idle>
        </G>
        {/* জাল: খুঁটির মাথা থেকে ঝুলছে */}
        <G x={bx - 140 + 90} y={netY} o={C.seg(tNet - 0.1, tNet + 0.3)}><Net rx={70} ry={50} /></G>
        {fishOut.map((f, i) => f.p > 0 && f.p < 1 && (
          <G key={i} x={f.x} y={f.y} s={0.42} r={f.r}><Hilsa /></G>
        ))}
      </g>

      {/* এই ইলিশ নদীর বাসিন্দা না */}
      {hiP > 0 && (
        <g opacity={C.seg(tHighlight, tHighlight + 0.3) * (1 - C.seg(at(2, "থাকে") + 0.6, at(2, "থাকে") + 1.2))}>
          <G x={960} y={340} s={1.15 * hiP}><Idle amp={5} speed={2.4} rot={2}><Hilsa glow /></Idle></G>
          <Chip x={900} y={480} text="নদীর বাসিন্দা" p={C.pop(at(2, "নদীর"))} tone={T.accent} />
          <XMark x={1130} y={480} size={34} p={C.seg(at(2, "না"), at(2, "না") + 0.5)} />
        </g>
      )}
    </g>
  );
};
