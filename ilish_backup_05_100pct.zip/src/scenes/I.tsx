import React from "react";
import { useCurrentFrame } from "remotion";
import { theme as T, FONT } from "../theme";
import { clock, SPRING } from "../motion";
import { at, cs } from "../cues";
import { Hilsa, Water, G, Idle } from "../art";

// সিন I: রিক্যাপ — মা বাঁচানো, বাচ্চা বাঁচানো, নদী বাঁচানো
export const SceneI: React.FC = () => {
  const C = clock(useCurrentFrame());
  const tIn = at(22, "তাহলে") - 0.5, times = [at(22, "মা"), at(22, "বাচ্চা"), at(22, "নদী", 1)];
  const titles = ["মা বাঁচানো", "বাচ্চা বাঁচানো", "নদী বাঁচানো"];
  return (
    <g>
      {titles.map((title, i) => {
        const y = 270 + i * 190, ph = C.pop(tIn + 0.1 + i * 0.12, SPRING.soft), on = C.pop(times[i], SPRING.pop);
        const lit = on > 0.5;
        return (
          <g key={i} transform={`translate(960 ${y + (1 - ph) * 30})`} opacity={Math.max(ph * 0.35, on)}>
            <rect x={-620} y={-76} width={1240} height={152} rx={26} fill={T.surface} stroke={lit ? T.accent : T.border} strokeWidth={lit ? 4 : 2} style={{ filter: lit ? `drop-shadow(0 0 20px ${T.accent}66)` : "none" }} />
            <rect x={-590} y={-46} width={92} height={92} rx={20} fill={T.accent} />
            <text x={-544} y={20} textAnchor="middle" fontFamily={FONT} fontWeight={700} fontSize={58} fill={T.onAccent}>{["১", "২", "৩"][i]}</text>
            <text x={-440} y={22} fontFamily={FONT} fontWeight={700} fontSize={64} fill={T.text}>{title}</text>
            <g transform="translate(400 0)">
              {i === 0 && <G s={0.5}><Idle amp={2} speed={2.4} rot={2}><Hilsa eggs wobble={2} /></Idle></G>}
              {i === 1 && <><G x={-70} y={-12} s={0.34}><Hilsa wobble={3} /></G><G x={30} y={22} s={0.3}><Hilsa wobble={3} /></G><G x={80} y={-26} s={0.28}><Hilsa wobble={3} /></G></>}
              {i === 2 && <g><Water x0={-130} x1={130} y0={-30} y1={40} fill={T.river} deep={T.riverDeep} amp={5} /><G x={0} y={6} s={0.3}><Hilsa wobble={3} /></G></g>}
            </g>
          </g>
        );
      })}
    </g>
  );
};
