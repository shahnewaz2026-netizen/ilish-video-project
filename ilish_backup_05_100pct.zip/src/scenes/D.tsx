import React from "react";
import { useCurrentFrame } from "remotion";
import { theme as T } from "../theme";
import { clock, lerp, easeOut, clamp01 } from "../motion";
import { at, cs } from "../cues";
import { countAt, toBn } from "../helpers.mjs";
import { Hilsa, Pearls, Net, Basket, Truck, Calendar, G, Idle } from "../art";
import { Chip, XMark, Stamp, NumCard, Bar, Arrow } from "../components/ui";

const MiniFish = React.memo(({ ghost = 0 }: { ghost?: number }) => <Hilsa ghost={ghost} />);

// সিন D: ধাপ ১ — মা বাঁচানো
export const SceneD: React.FC = () => {
  const C = clock(useCurrentFrame());
  const vis = (a: number, b: number, f = 0.45) => C.seg(a, a + f) * (1 - C.seg(b, b + f));

  const tMotherChip = at(8, "মা", 0), tEggChip = at(8, "ডিম"), tRun = at(8, "ধরুন"), tGhat = at(8, "ঘাটে"), tHundred = at(8, "একশটা");
  const tNet = at(9, "জাল"), tFifty = at(9, "পঞ্চাশটা"), tBefore = at(9, "ডিম");
  const tLay = at(10, "ডিম"), tRest = at(10, "বাকি"), tMeans = at(10, "মানে"), tHalf = at(10, "অর্ধেকে"), tAlmost = at(10, "প্রায়");
  const tCal = cs(11), tOct = at(11, "অক্টোবরের"), t22 = at(11, "বাইশ"), tCatch = at(11, "ধরা"), tSell = at(11, "বেচা"), tMove = at(12, "নেওয়া"), tBan = at(12, "বন্ধ");

  // ── ১. মা ইলিশ বড় করে ──
  const motherV = vis(cs(8) - 0.1, tRun + 0.1);
  // ── ২. একশো মা ইলিশের গ্রিড ──
  const gridV = vis(tGhat, tMeans + 0.1, 0.4);
  const cols = 20, x0 = 162, dx = 84, y0 = 345, dy = 96;
  const caught = C.seg(tFifty, tFifty + 0.5);
  const cnt = countAt(C.t, tHundred, 1.0, 0, 100);
  // জালের নামা
  const netV = vis(tNet, tLay, 0.5);
  const netY = lerp(60, 535, C.seg(tNet, tNet + 1.0, easeOut));
  // ── ৩. বার ──
  const barV = vis(tMeans + 0.3, cs(11) - 0.1, 0.5);
  const barVal = lerp(1, 0.5, C.seg(tHalf - 0.3, tHalf + 0.8));
  // ── ৪. ক্যালেন্ডার ও নিষেধ ──
  const calV = vis(tCal - 0.1, 99, 0.5);
  const days = countAt(C.t, t22, 1.1, 0, 22);

  return (
    <g>
      {/* মা ইলিশ */}
      {motherV > 0.01 && (
        <g opacity={motherV}>
          <G x={960} y={470} s={1.55 * C.pop(cs(8))}><Idle amp={5} speed={2.2} rot={2}><Hilsa eggs glow wobble={2} /></Idle></G>
          <Chip x={820} y={290} text="মা ইলিশ" p={C.pop(tMotherChip)} tone={T.accent} solid size={38} />
          <Chip x={1090} y={680} text="ডিম পাড়ার জন্য তৈরি" p={C.pop(tEggChip)} tone={T.warn} />
        </g>
      )}

      {/* একশো মা ইলিশ */}
      {gridV > 0.01 && (
        <g opacity={gridV}>
          {Array.from({ length: 100 }, (_, i) => {
            const col = i % cols, row = Math.floor(i / cols);
            const x = x0 + col * dx, y = y0 + row * dy;
            const p = C.pop(tGhat + 0.1 + (i / 100) * 1.6, { damping: 18, stiffness: 160, mass: 0.7 });
            const right = col >= 10;
            const o = right ? 1 - 0.7 * caught : 1;
            const layP = !right ? C.seg(tLay + col * 0.05 + row * 0.04, tLay + col * 0.05 + row * 0.04 + 0.5) : 0;
            return (
              <g key={i}>
                <G x={x} y={y} s={0.3 * p} o={p * o}><MiniFish /></G>
                {layP > 0 && <Pearls pts={[[x - 10, y + 30], [x + 10, y + 34]]} r={5} o={layP} />}
              </g>
            );
          })}
          {/* ১০০ কার্ড */}
          <g opacity={1 - C.seg(tNet, tNet + 0.3)}>
            <NumCard x={960} y={235} num={toBn(cnt)} unit="মা ইলিশ" p={C.pop(tHundred)} w={360} h={110} numSize={68} tone={T.accent} />
          </g>
          {/* ৫০ জালে / ৫০ বাকি */}
          <NumCard x={1380} y={235} num="৫০" unit="জালে" p={C.pop(tFifty)} w={300} h={110} numSize={64} tone={T.bad} />
          <NumCard x={540} y={235} num="৫০" unit="বাকি" p={C.pop(tRest)} w={300} h={110} numSize={64} tone={T.good} />
          <Chip x={1380} y={808} text="ডিম পাড়ার আগেই" p={C.pop(tBefore)} tone={T.bad} />
          <Chip x={540} y={808} text="ডিম দেবে" p={C.pop(tLay)} tone={T.warn} />
        </g>
      )}
      {netV > 0.01 && (
        <g opacity={netV}>
          <G x={1380} y={netY}><Net rx={430} ry={235} fill={0.12} /></G>
          <XMark x={1380} y={netY} size={60} p={C.seg(tFifty, tFifty + 0.5)} />
        </g>
      )}

      {/* পরের বছরের ইলিশ: বার */}
      {barV > 0.01 && (
        <g opacity={barV}>
          <Chip x={960} y={380} text="পরের বছরের ইলিশ" p={1} tone={T.accent} size={40} />
          <G x={330} y={520} s={0.7}><Idle amp={4} speed={2.4} rot={2}><Hilsa wobble={3} /></Idle></G>
          <Bar x={470} y={500} w={1000} v={barVal} h={44} tone={barVal < 0.8 ? T.bad : T.data} />
          <Arrow x1={1100} y1={620} x2={800} y2={620} p={C.seg(tHalf, tHalf + 0.5)} tone={T.bad} />
          <Chip x={960} y={720} text="প্রায় অর্ধেক" p={C.pop(tAlmost)} tone={T.bad} size={44} />
        </g>
      )}

      {/* ক্যালেন্ডার + তিনটা নিষেধ */}
      {calV > 0.01 && (
        <g opacity={calV}>
          <G x={420} y={760} s={1.45 * C.pop(tCal)}><Calendar head="অক্টোবর" marks={Math.min(15, Math.round((days * 15) / 22))} /></G>
          <NumCard x={420} y={330} num={toBn(days)} unit="দিন" p={C.pop(t22)} w={320} h={120} numSize={72} tone={T.warn} />
          {/* ধরা */}
          <G x={940} y={610} s={C.pop(tCatch)}><Idle amp={4} speed={2}><Net rx={110} ry={80} /></Idle></G>
          <Chip x={940} y={760} text="ধরা" p={C.pop(tCatch)} tone={T.data} />
          <XMark x={940} y={610} size={56} p={C.seg(tCatch + 0.5, tCatch + 1.0)} />
          {/* বেচা */}
          <G x={1280} y={700} s={1.5 * C.pop(tSell)}><Idle amp={3} speed={2.2}><Basket fish={4} /></Idle></G>
          <Chip x={1280} y={760} text="বেচা" p={C.pop(tSell)} tone={T.data} />
          <XMark x={1280} y={600} size={56} p={C.seg(tSell + 0.5, tSell + 1.0)} />
          {/* নেওয়া */}
          <G x={1620} y={700} s={1.1 * C.pop(tMove)}><Idle amp={3} speed={2.6}><Truck /></Idle></G>
          <Chip x={1620} y={760} text="নেওয়া" p={C.pop(tMove)} tone={T.data} />
          <XMark x={1620} y={590} size={56} p={C.seg(tMove + 0.5, tMove + 1.0)} />
          <Stamp x={1280} y={340} text="বন্ধ" p={C.seg(tBan, tBan + 0.35)} size={60} />
        </g>
      )}
    </g>
  );
};
