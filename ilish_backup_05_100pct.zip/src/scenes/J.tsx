import React from "react";
import { useCurrentFrame } from "remotion";
import { theme as T, FONT } from "../theme";
import { clock, lerp, easeIO, easeOut } from "../motion";
import { at, cs } from "../cues";
import { Hilsa, Water, Pearls, Person, PriceTag, Plane, G, Idle } from "../art";
import { Chip, Arrow } from "../components/ui";

// সিন J: আউট্রো — অতিথি আসে ডিম পাড়তে, ফেরা ঠিক করে নদী; বন্ধুকে পাঠান; অতিথি না এলে দাম বাড়বে
export const SceneJ: React.FC = () => {
  const C = clock(useCurrentFrame());
  const vis = (a: number, b: number, f = 0.5) => C.seg(a, a + f) * (1 - C.seg(b, b + f));
  const tGuest = cs(23) - 0.2, tEgg = at(23, "ডিম"), tBack = at(23, "ফিরবে"), tDecide = at(23, "ঠিক"), tRiver = at(23, "নদী");
  const tPrice = at(23, "ইলিশের"), tFriend = at(23, "বন্ধুকে"), tSend = at(23, "পাঠান"), tNo = at(24, "অতিথি"), tUp = at(24, "দাম");

  const vA = vis(tGuest - 0.3, tPrice - 0.2);
  const vB = vis(tPrice - 0.2, 999);
  const fx = lerp(420, 1260, C.seg(tGuest, tEgg + 0.4, easeIO));
  const fy = 590 + Math.sin(C.t * 3) * 7;
  const glow = C.seg(tDecide, tDecide + 0.6);
  const sendP = C.seg(tSend, tSend + 1.0, easeOut);
  const priceUp = C.seg(tUp, tUp + 1.2);

  return (
    <g>
      {vA > 0.01 && (
        <g opacity={vA}>
          <Water x0={100} x1={1820} y0={400} y1={850} fill={T.river} deep={T.riverDeep} amp={6} speed={0.7} />
          <g opacity={glow}><rect x={100} y={396} width={1720} height={454} fill="none" stroke={T.accent} strokeWidth={5} style={{ filter: `drop-shadow(0 0 22px ${T.accent})` }} /></g>
          <G x={fx} y={fy} s={1.1 * C.pop(tGuest)}><Idle amp={2} speed={3} rot={2}><Hilsa wobble={3} /></Idle></G>
          <Chip x={fx} y={fy - 125} text="অতিথি" p={C.pop(tGuest + 0.1)} tone={T.accent} solid size={32} />
          <Pearls pts={Array.from({ length: 8 }, (_, i) => [1160 + (i % 4) * 40, 790 + Math.floor(i / 4) * 28] as [number, number])} r={10} o={C.seg(tEgg, tEgg + 0.6)} />
          <Chip x={1270} y={700} text="ডিম পাড়তে" p={C.pop(tEgg)} tone={T.warn} />
          <Chip x={960} y={310} text="আমাদের নদী" p={C.pop(tRiver)} tone={T.flow} size={46} />
          {C.t >= tBack && (
            <g opacity={C.seg(tBack, tBack + 0.3)}>
              <circle cx={fx + 110} cy={fy - 90} r={40} fill={T.surface} stroke={T.warn} strokeWidth={4} />
              <text x={fx + 110} y={fy - 72} textAnchor="middle" fontFamily={FONT} fontWeight={700} fontSize={56} fill={T.warn}>?</text>
            </g>
          )}
        </g>
      )}
      {vB > 0.01 && (
        <g opacity={vB}>
          {/* বন্ধু: ইলিশের দামে বিরক্ত */}
          <G x={1400} y={720} s={1.15 * C.pop(tFriend - 0.3)}><Idle amp={2} speed={2}><Person pose="stand" cloth={T.cloth2} sad /></Idle></G>
          <G x={1400 - 10} y={430} s={C.pop(tPrice)} r={-6}><PriceTag text="দাম" up={priceUp > 0.5} /></G>
          <Chip x={1400} y={780} text="বন্ধু" p={C.pop(tFriend)} tone={T.data} size={30} />
          {/* তুমি (পাঠাচ্ছ) */}
          <G x={430} y={720} s={1.15 * C.pop(tFriend - 0.3)}><Idle amp={2} speed={2.2}><Person pose="hold" /></Idle></G>
          <G x={lerp(520, 1330, sendP)} y={lerp(560, 520, sendP) - Math.sin(sendP * Math.PI) * 60} r={-12} o={sendP > 0 && sendP < 1 ? 1 : 0}><Plane /></G>
          <Arrow x1={560} y1={570} x2={1260} y2={570} p={C.seg(tSend - 0.2, tSend + 0.7)} tone={T.accent} />
          {/* বড় শেয়ার */}
          <g transform={`translate(960 270) scale(${0.88 + 0.12 * C.pop(tSend)})`} opacity={C.pop(tSend)} style={{ filter: `drop-shadow(0 0 18px ${T.accent}88)` }}>
            <rect x={-300} y={-60} width={600} height={120} rx={60} fill={T.accent} />
            <text x={30} y={20} textAnchor="middle" fontFamily={FONT} fontWeight={700} fontSize={64} fill={T.onAccent}>বন্ধুকে পাঠান</text>
            <g transform="translate(-220 0)" fill="none" stroke={T.onAccent} strokeWidth={7} strokeLinecap="round" strokeLinejoin="round"><circle cx={-18} cy={0} r={9} fill={T.onAccent} /><circle cx={22} cy={-22} r={9} fill={T.onAccent} /><circle cx={22} cy={22} r={9} fill={T.onAccent} /><path d="M -10 -4 L 14 -18 M -10 4 L 14 18" /></g>
          </g>
          {/* অতিথি না এলে দাম বাড়বে */}
          <g opacity={C.pop(tNo)}>
            <G x={960} y={440} s={1}><Hilsa ghost={0.85} /></G>
            <Chip x={960} y={650} text="অতিথি না এলে" p={C.pop(tNo)} tone={T.bad} size={34} />
          </g>
          <G x={960} y={790} s={1.25 * C.pop(tUp)}><PriceTag text="দাম" up /></G>
        </g>
      )}
    </g>
  );
};
