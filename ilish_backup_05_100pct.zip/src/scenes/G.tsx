import React from "react";
import { useCurrentFrame } from "remotion";
import { theme as T } from "../theme";
import { clock, lerp, easeIO } from "../motion";
import { at, cs } from "../cues";
import { countAt } from "../helpers.mjs";
import { Hilsa, Water, Sun, Clipboard, Drop, G, Idle } from "../art";
import { Chip, NumCard, Bar, Arrow, Stamp } from "../components/ui";

// সিন G: ধাপ ৩ — নদী বাঁচানো (নোনা পানি বাড়ছে)
export const SceneG: React.FC = () => {
  const C = clock(useCurrentFrame());
  const WL = 420;
  const tTitle = cs(18), tDry = at(19, "শুকনো"), tLess = at(19, "কমছে"), tSalt = at(19, "নোনা"), tSurvey = at(19, "জরিপ"), tMeghna = at(19, "মেঘনার"), tDouble = at(20, "দ্বিগুণ");

  const dry = C.seg(tDry, tDry + 1.2), less = C.seg(tLess - 0.2, tLess + 1.2);
  const salty = C.seg(tSalt, tSalt + 2.0, easeIO);
  const dbl = C.seg(tDouble - 0.3, tDouble + 1.0);
  const front = lerp(700, 1220, salty * 0.55 + dbl * 0.45);
  const count = countAt(C.t, tDouble, 0.9, 1, 2);

  return (
    <g>
      <Water x0={100} x1={front} y0={WL} y1={850} fill={T.sea} deep={T.seaDeep} amp={8} />
      <Water x0={front} x1={1820} y0={WL} y1={850} fill={T.river} deep={T.riverDeep} amp={5} speed={0.7} o={1 - 0.0 * dry} />
      <line x1={front} y1={WL} x2={front} y2={850} stroke={T.salt} strokeWidth={4} strokeDasharray="10 10" opacity={0.8 * C.seg(tSalt, tSalt + 0.5)} />

      {/* নোনা কণা */}
      {Array.from({ length: 26 }, (_, i) => {
        const x = lerp(240 + ((i * 131) % 600), 300 + ((i * 131) % 1000), salty), y = 470 + ((i * 71) % 330);
        const inRiver = x > 940;
        const show = (inRiver ? salty : 1) * C.seg(tSalt, tSalt + 0.6);
        return <circle key={i} cx={x + Math.sin(C.t * 2 + i) * 6} cy={y + Math.cos(C.t * 1.7 + i) * 5} r={7} fill={T.salt} opacity={show * 0.9} />;
      })}

      {/* শুকনো মৌসুম: সূর্য */}
      <G x={1560} y={252} s={C.pop(tDry)} o={1}><Sun r={46} /></G>
      <Chip x={1560} y={372} text="শুকনো মৌসুম" p={C.pop(tDry)} tone={T.warn} />

      {/* মিঠা পানি কমছে */}
      <G x={1560} y={470} s={C.pop(tLess)}><Drop fill={T.good} /></G>
      <g opacity={C.pop(tLess)}><Bar x={1420} y={520} w={280} v={1 - 0.7 * less} tone={T.good} h={24} /></g>
      <Chip x={1560} y={600} text="মিঠা পানি কমছে" p={C.pop(tLess)} tone={T.good} size={30} />

      <Chip x={1250} y={330} text="নদী" p={C.pop(tTitle + 0.6)} tone={T.flow} size={40} />
      {/* নোনা ভাব বাড়ছে */}
      <Chip x={470} y={330} text="নোনা ভাব বাড়ছে" p={C.pop(tSalt)} tone={T.salt} />
      <Arrow x1={470} y1={380} x2={470 + lerp(0, 340, salty)} y2={470} p={C.seg(tSalt, tSalt + 0.6)} tone={T.salt} />

      {/* জরিপ */}
      <G x={820} y={300} s={C.pop(tSurvey)}><Idle amp={3} speed={2}><Clipboard /></Idle></G>
      <Chip x={820} y={346} text="জরিপ" p={C.pop(tSurvey)} tone={T.accent} size={30} />
      {/* মেঘনার মোহনা */}
      <Chip x={front} y={790} text="মেঘনার মোহনা" p={C.pop(tMeghna)} tone={T.accent} solid size={36} />
      <g opacity={C.pop(tMeghna)}><line x1={front} y1={745} x2={front} y2={700} stroke={T.accent} strokeWidth={4} strokeLinecap="round" /></g>
      {/* দ্বিগুণ */}
      <NumCard x={960} y={560} num={`×${count === 1 ? "১" : "২"}`} unit="নোনা" p={C.pop(tDouble)} tone={T.salt} w={340} h={130} numSize={84} />
      <Stamp x={front + 280} y={790} text="দ্বিগুণ" p={C.seg(tDouble + 0.5, tDouble + 0.85)} tone={T.warn} size={44} />
    </g>
  );
};
