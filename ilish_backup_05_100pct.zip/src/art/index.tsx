import React from "react";
import { useCurrentFrame } from "remotion";
import { theme as T, FONT } from "../theme";
import { FPS } from "../motion";

const S = { stroke: T.line, strokeWidth: 4, strokeLinejoin: "round" as const, strokeLinecap: "round" as const };

// ── পজিশন-র‍্যাপার: (x,y) বসায়, s স্কেল, r কাত, fx উল্টায়, o অপাসিটি ──
export const G: React.FC<{ x?: number; y?: number; s?: number; r?: number; fx?: boolean; o?: number; children?: React.ReactNode }> =
  ({ x = 0, y = 0, s = 1, r = 0, fx = false, o = 1, children }) => (
    <g transform={`translate(${x} ${y}) rotate(${r}) scale(${fx ? -s : s} ${s})`} opacity={o}>{children}</g>
  );

// পুরো-বস্তুর দোলা
export const Idle: React.FC<{ amp?: number; speed?: number; ph?: number; rot?: number; children?: React.ReactNode }> =
  ({ amp = 3, speed = 2, ph = 0, rot = 0, children }) => {
    const t = useCurrentFrame() / FPS;
    return <g transform={`translate(0 ${Math.sin(t * speed + ph) * amp}) rotate(${Math.sin(t * speed * 0.8 + ph) * rot})`}>{children}</g>;
  };

// ── ইলিশ (পাশ-দেখা): (0,0) = দেহের কেন্দ্র; মাথা ডানে; চওড়া ≈ ২৪০ ──
export const Hilsa: React.FC<{ ghost?: number; eggs?: boolean; glow?: boolean; tint?: string; wobble?: number }> =
  ({ ghost = 0, eggs = false, glow = false, tint, wobble = 0 }) => {
    const t = useCurrentFrame() / FPS;
    const fill = tint ?? T.fish;
    const wob = wobble ? `rotate(${Math.sin(t * 4) * wobble})` : "";
    if (ghost > 0) {
      return (
        <g opacity={ghost} transform={wob}>
          <path d="M -100 0 Q -60 -42 20 -40 Q 80 -34 104 0 Q 80 34 20 36 Q -60 42 -100 0 Z M -96 0 L -140 -34 Q -124 0 -140 34 Z" fill="none" stroke={T.muted} strokeWidth={4} strokeDasharray="12 10" strokeLinejoin="round" />
        </g>
      );
    }
    return (
      <g transform={wob} style={glow ? { filter: `drop-shadow(0 0 18px ${T.data})` } : undefined}>
        <path d="M -96 0 L -142 -36 Q -124 0 -142 36 Z" fill={T.fishBack} {...S} />
        <path d="M -10 -38 L 12 -66 L 38 -36 Z" fill={T.fishBack} {...S} />
        <path d="M -100 0 Q -60 -42 20 -40 Q 80 -34 104 0 Q 80 34 20 36 Q -60 42 -100 0 Z" fill={fill} {...S} />
        <path d="M -92 -6 Q -60 -36 20 -37 Q 74 -31 96 -4 Q 40 -20 -92 -6 Z" fill={T.fishBack} opacity={0.75} />
        <path d="M -70 12 Q -10 30 60 14 Q 20 36 -40 32 Z" fill={T.fishHi} opacity={0.9} />
        <path d="M 44 -26 Q 32 0 44 26" fill="none" stroke={T.line} strokeWidth={3} strokeLinecap="round" />
        <circle cx={68} cy={-7} r={8} fill={T.fishHi} stroke={T.line} strokeWidth={2.5} />
        <circle cx={70} cy={-7} r={3.6} fill={T.line} />
        <path d="M -30 -8 q 10 8 20 0 M -6 -8 q 10 8 20 0 M -18 8 q 10 8 20 0" fill="none" stroke={T.line} strokeWidth={2} opacity={0.35} strokeLinecap="round" />
        {eggs && [[-40, 8], [-22, 14], [-4, 8], [-30, -4], [-12, 0], [8, 12]].map(([x, y], i) => (
          <circle key={i} cx={x} cy={y} r={7} fill={T.warn} stroke={T.line} strokeWidth={2} />
        ))}
      </g>
    );
  };

// ── ডিম (মুক্তোর মতো) ──
export const Pearls: React.FC<{ pts: [number, number][]; r?: number; o?: number }> = ({ pts, r = 8, o = 1 }) => (
  <g opacity={o}>{pts.map(([x, y], i) => <circle key={i} cx={x} cy={y} r={r} fill={T.accent} stroke={T.line} strokeWidth={2} />)}</g>
);

// ── আইকন-মানুষ: (0,0) = পায়ের তলার মাঝ; উচ্চতা ≈ ২১০ ──
export const Person: React.FC<{ pose?: "stand" | "point" | "hold" | "wave"; cloth?: string; hair?: string; sad?: boolean; scale?: number }> =
  ({ pose = "stand", cloth = T.cloth, hair = T.hair, sad = false, scale = 1 }) => (
    <g transform={`scale(${scale})`}>
      <rect x={-23} y={-72} width={19} height={72} rx={9} fill={T.landHi} {...S} />
      <rect x={4} y={-72} width={19} height={72} rx={9} fill={T.landHi} {...S} />
      {pose === "stand" && (<>
        <rect x={-50} y={-136} width={16} height={68} rx={8} fill={T.skin} {...S} />
        <rect x={34} y={-136} width={16} height={68} rx={8} fill={T.skin} {...S} /></>)}
      {pose === "point" && (<>
        <rect x={-50} y={-136} width={16} height={68} rx={8} fill={T.skin} {...S} />
        <path d="M 30 -122 L 100 -142" stroke={T.line} strokeWidth={22} strokeLinecap="round" fill="none" />
        <path d="M 30 -122 L 100 -142" stroke={T.skin} strokeWidth={14} strokeLinecap="round" fill="none" /></>)}
      {pose === "wave" && (<>
        <rect x={-50} y={-136} width={16} height={68} rx={8} fill={T.skin} {...S} />
        <path d="M 30 -122 L 62 -190" stroke={T.line} strokeWidth={22} strokeLinecap="round" fill="none" />
        <path d="M 30 -122 L 62 -190" stroke={T.skin} strokeWidth={14} strokeLinecap="round" fill="none" /></>)}
      {pose === "hold" && (<>
        <path d="M -30 -122 L 6 -96 M 30 -122 L 6 -96" stroke={T.line} strokeWidth={22} strokeLinecap="round" fill="none" />
        <path d="M -30 -122 L 6 -96 M 30 -122 L 6 -96" stroke={T.skin} strokeWidth={14} strokeLinecap="round" fill="none" />
        <rect x={-6} y={-124} width={24} height={34} rx={5} fill={T.fish} {...S} strokeWidth={3} /></>)}
      <rect x={-33} y={-142} width={66} height={78} rx={26} fill={cloth} {...S} />
      <circle cx={0} cy={-172} r={30} fill={T.skin} {...S} />
      <path d="M -30 -176 Q -28 -208 0 -208 Q 28 -208 30 -176 Q 12 -192 -30 -176 Z" fill={hair} />
      <circle cx={-10} cy={-170} r={3.5} fill={T.line} /><circle cx={10} cy={-170} r={3.5} fill={T.line} />
      <path d={sad ? "M -9 -153 Q 0 -160 9 -153" : "M -9 -158 Q 0 -151 9 -158"} stroke={T.line} strokeWidth={3.5} fill="none" strokeLinecap="round" />
    </g>
  );

// ── নৌকা: (0,0) = জলরেখার মাঝ; চওড়া ≈ 340 ──
export const Boat: React.FC<{ pole?: boolean }> = ({ pole = true }) => (
  <g>
    {pole && <g>
      <path d="M -120 -46 L -120 -200 L -20 -200" fill="none" stroke={T.line} strokeWidth={14} strokeLinecap="round" strokeLinejoin="round" />
      <path d="M -120 -46 L -120 -200 L -20 -200" fill="none" stroke={T.woodDeep} strokeWidth={7} strokeLinecap="round" strokeLinejoin="round" />
    </g>}
    <rect x={20} y={-112} width={96} height={66} rx={10} fill={T.cloth} {...S} />
    <rect x={32} y={-100} width={30} height={26} rx={5} fill={T.fishHi} {...S} strokeWidth={3} />
    <path d="M 10 -112 L 126 -112" stroke={T.line} strokeWidth={8} strokeLinecap="round" />
    <path d="M -170 -46 L 176 -46 Q 150 4 96 4 L -100 4 Q -150 4 -170 -46 Z" fill={T.wood} {...S} />
    <path d="M -160 -32 L 166 -32" stroke={T.accent} strokeWidth={7} opacity={0.9} />
  </g>
);

// ── জাল (মেশ): (0,0) = কেন্দ্র ──
export const Net: React.FC<{ rx?: number; ry?: number; fill?: number; tone?: string }> = ({ rx = 90, ry = 62, fill = 0.25, tone = T.accent }) => {
  const lines: React.ReactNode[] = [];
  const n = 5;
  for (let k = -n + 1; k < n; k++) {
    const x = (k / n) * rx, hy = ry * Math.sqrt(1 - (x / rx) ** 2);
    const y = (k / n) * ry, hx = rx * Math.sqrt(1 - (y / ry) ** 2);
    lines.push(<line key={"v" + k} x1={x} y1={-hy} x2={x} y2={hy} stroke={tone} strokeWidth={2.5} opacity={0.85} />);
    lines.push(<line key={"h" + k} x1={-hx} y1={y} x2={hx} y2={y} stroke={tone} strokeWidth={2.5} opacity={0.85} />);
  }
  return (
    <g>
      <ellipse rx={rx} ry={ry} fill={tone} opacity={fill} />
      {lines}
      <ellipse rx={rx} ry={ry} fill="none" stroke={tone} strokeWidth={6} />
    </g>
  );
};

// ── জলের ফালি (ঢেউ চলে) ──
export const Water: React.FC<{ x0: number; x1: number; y0: number; y1: number; fill: string; deep?: string; amp?: number; speed?: number; o?: number }> =
  ({ x0, x1, y0, y1, fill, deep, amp = 7, speed = 1, o = 1 }) => {
    const t = useCurrentFrame() / FPS;
    const wave = (yy: number, a: number, ph: number) => {
      let d = `M ${x0} ${yy}`;
      const pts: number[] = [];
      for (let x = x0; x < x1; x += 24) pts.push(x);
      pts.push(x1);
      for (const x of pts) d += ` L ${x} ${yy + Math.sin(x / 70 + t * 1.6 * speed + ph) * a}`;
      return d;
    };
    return (
      <g opacity={o}>
        <path d={`${wave(y0, amp, 0)} L ${x1} ${y1} L ${x0} ${y1} Z`} fill={fill} />
        {deep && <path d={`${wave(y0 + (y1 - y0) * 0.55, amp * 0.8, 2)} L ${x1} ${y1} L ${x0} ${y1} Z`} fill={deep} opacity={0.7} />}
        <path d={wave(y0, amp, 0)} fill="none" stroke={T.fishHi} strokeWidth={3} opacity={0.35} />
      </g>
    );
  };

// ── পাড়/ঘাট: (x0..x1, উপরের রেখা y) ──
export const Bank: React.FC<{ x0: number; x1: number; y: number; h?: number }> = ({ x0, x1, y, h = 120 }) => (
  <g>
    <rect x={x0} y={y} width={x1 - x0} height={h} fill={T.land} stroke={T.line} strokeWidth={4} />
    <rect x={x0} y={y} width={x1 - x0} height={12} fill={T.landHi} />
  </g>
);
export const Pier: React.FC<{ x0: number; x1: number; y: number }> = ({ x0, x1, y }) => (
  <g>
    {[x0 + 20, (x0 + x1) / 2, x1 - 20].map((x) => <rect key={x} x={x - 9} y={y} width={18} height={150} rx={4} fill={T.woodDeep} {...S} strokeWidth={3} />)}
    <rect x={x0} y={y - 16} width={x1 - x0} height={20} rx={6} fill={T.wood} {...S} />
    {Array.from({ length: Math.floor((x1 - x0) / 56) }, (_, i) => <line key={i} x1={x0 + 28 + i * 56} y1={y - 14} x2={x0 + 28 + i * 56} y2={y + 2} stroke={T.line} strokeWidth={2.5} opacity={0.5} />)}
  </g>
);

// ── ঝুড়ি: (0,0) = তলার মাঝ ──
export const Basket: React.FC<{ fish?: number }> = ({ fish = 0 }) => (
  <g>
    {Array.from({ length: fish }, (_, i) => <g key={i} transform={`translate(${-34 + i * 34} ${-70 - (i % 2) * 8}) rotate(${-20 + i * 14}) scale(0.28)`}><Hilsa /></g>)}
    <path d="M -64 -60 L 64 -60 L 50 0 L -50 0 Z" fill={T.wood} {...S} />
    <path d="M -58 -40 L 58 -40 M -54 -20 L 54 -20 M -20 -60 L -16 0 M 20 -60 L 16 0" stroke={T.line} strokeWidth={3} opacity={0.5} />
    <rect x={-70} y={-68} width={140} height={14} rx={7} fill={T.woodDeep} {...S} />
  </g>
);

// ── ট্রাক ──
export const Truck: React.FC = () => (
  <g>
    <rect x={-120} y={-120} width={150} height={90} rx={10} fill={T.fish} {...S} />
    <path d="M 36 -100 L 84 -100 L 118 -62 L 118 -30 L 36 -30 Z" fill={T.cloth2} {...S} />
    <path d="M 48 -90 L 78 -90 L 100 -64 L 48 -64 Z" fill={T.fishHi} {...S} strokeWidth={3} />
    {[-70, 70].map((x) => <g key={x} transform={`translate(${x} -22)`}><circle r={24} fill={T.line} {...S} /><circle r={9} fill={T.fish} /></g>)}
    <g transform="translate(-45 -75) scale(0.3)"><Hilsa /></g>
  </g>
);

// ── ক্যালেন্ডার: (0,0) = তলার মাঝ; ২২০×২০০ ──
export const Calendar: React.FC<{ head: string; marks?: number; mark?: string }> = ({ head, marks = 0, mark = T.bad }) => (
  <g>
    <rect x={-110} y={-200} width={220} height={200} rx={20} fill={T.surfaceHi} {...S} />
    <path d="M -110 -160 L -110 -180 Q -110 -200 -90 -200 L 90 -200 Q 110 -200 110 -180 L 110 -160 Z" fill={T.bad} {...S} />
    {[-60, 60].map((x) => <rect key={x} x={x - 7} y={-216} width={14} height={34} rx={7} fill={T.accent} {...S} strokeWidth={3} />)}
    <text x={0} y={-168} textAnchor="middle" fontFamily={FONT} fontWeight={700} fontSize={26} fill={T.accent}>{head}</text>
    {Array.from({ length: 15 }, (_, i) => {
      const cx = -80 + (i % 5) * 40, cy = -128 + Math.floor(i / 5) * 40;
      return <rect key={i} x={cx - 14} y={cy - 14} width={28} height={28} rx={6} fill={i < marks ? mark : T.border} opacity={i < marks ? 1 : 0.7} />;
    })}
  </g>
);

export const Sun: React.FC<{ r?: number }> = ({ r = 46 }) => {
  const t = useCurrentFrame() / FPS;
  return (
    <g>
      <g transform={`rotate(${t * 12})`}>{Array.from({ length: 12 }, (_, i) => <line key={i} x1={r + 14} y1={0} x2={r + 34} y2={0} transform={`rotate(${i * 30})`} stroke={T.warn} strokeWidth={7} strokeLinecap="round" />)}</g>
      <circle r={r} fill={T.warn} {...S} />
    </g>
  );
};
export const Cloud: React.FC<{ o?: number }> = ({ o = 0.5 }) => (
  <g opacity={o}><ellipse cx={0} cy={0} rx={70} ry={26} fill={T.fish} /><circle cx={-24} cy={-22} r={26} fill={T.fish} /><circle cx={20} cy={-30} r={32} fill={T.fish} /></g>
);
export const Drop: React.FC<{ fill?: string }> = ({ fill = T.warn }) => (
  <path d="M 0 -34 Q 22 -6 22 8 A 22 22 0 0 1 -22 8 Q -22 -6 0 -34 Z" fill={fill} {...S} strokeWidth={3} />
);
export const Star: React.FC<{ fill?: string }> = ({ fill = T.warn }) => (
  <path d="M 0 -30 L 9 -9 L 32 -8 L 14 7 L 20 29 L 0 17 L -20 29 L -14 7 L -32 -8 L -9 -9 Z" fill={fill} {...S} strokeWidth={3} />
);
export const Plane: React.FC = () => (
  <path d="M -40 0 L 44 -26 L 18 0 L 44 26 Z M 18 0 L -8 0" fill={T.accent} {...S} />
);
export const PriceTag: React.FC<{ text: string; fill?: string; up?: boolean }> = ({ text, fill = T.bad, up = false }) => (
  <g>
    <path d="M -70 -34 L 40 -34 L 76 0 L 40 34 L -70 34 Z" fill={fill} {...S} />
    <circle cx={46} cy={0} r={7} fill={T.line} />
    <text x={up ? 0 : -12} y={12} textAnchor="middle" fontFamily={FONT} fontWeight={700} fontSize={34} fill={T.line}>{text}</text>
    {up && <path d="M -50 10 L -38 -10 L -26 10 Z M -38 8 L -38 22" fill={T.line} stroke={T.line} strokeWidth={5} strokeLinejoin="round" strokeLinecap="round" />}
  </g>
);
export const Clipboard: React.FC = () => (
  <g>
    <rect x={-50} y={-120} width={100} height={120} rx={12} fill={T.fishHi} {...S} />
    <rect x={-22} y={-132} width={44} height={22} rx={8} fill={T.fishBack} {...S} strokeWidth={3} />
    {[-86, -62, -38].map((y) => <line key={y} x1={-30} y1={y} x2={30} y2={y} stroke={T.line} strokeWidth={4} opacity={0.6} strokeLinecap="round" />)}
  </g>
);
