import { staticFile, delayRender, continueRender } from "remotion";

const BN = "U+0951-0952,U+0964-0965,U+0980-09FE,U+1CF7,U+200C-200D,U+20B9,U+25CC";
const LAT = "U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD";
const faces: [string, string, string][] = [
  ["fonts/hind-siliguri-bengali-600-normal.woff2", "600", BN],
  ["fonts/hind-siliguri-bengali-700-normal.woff2", "700", BN],
  ["fonts/hind-siliguri-latin-600-normal.woff2", "600", LAT],
  ["fonts/hind-siliguri-latin-700-normal.woff2", "700", LAT],
];

const handle = delayRender("fonts");
Promise.all(
  faces.map(([file, weight, range]) =>
    new FontFace("HindSiliguri", `url(${staticFile(file)})`, { weight, unicodeRange: range }).load(),
  ),
)
  .then((loaded) => { loaded.forEach((f) => (document as any).fonts.add(f)); continueRender(handle); })
  .catch(() => continueRender(handle));
