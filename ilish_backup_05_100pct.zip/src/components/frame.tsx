import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { theme as T, FONT } from "../theme";
import { L } from "../layout";
import { FPS, clamp01 } from "../motion";
import { chunkWords, captionState } from "../helpers.mjs";
import timing from "../timing.json";
import { at, cs } from "../cues";

// ── ব্যাকগ্রাউন্ড: bg + ডট-গ্রিড + কেন্দ্রের গ্লো ──
export const Bg: React.FC = () => (
  <AbsoluteFill style={{ background: T.bg }}>
    <svg width={L.w} height={L.h} style={{ position: "absolute", inset: 0 }}>
      <defs>
        <pattern id="dots" width={48} height={48} patternUnits="userSpaceOnUse"><circle cx={24} cy={24} r={1.5} fill={T.text} opacity={0.07} /></pattern>
        <radialGradient id="glow" cx="50%" cy="50%" r="50%"><stop offset="0%" stopColor={T.data} stopOpacity={0.14} /><stop offset="100%" stopColor={T.data} stopOpacity={0} /></radialGradient>
      </defs>
      <rect width={L.w} height={L.h} fill="url(#dots)" />
      <circle cx={L.w / 2} cy={(L.stage.top + L.stage.bottom) / 2} r={L.glowR} fill="url(#glow)" />
    </svg>
  </AbsoluteFill>
);

// ── সিন-র‍্যাপার: গ্লোবাল সময়ে [from,to] এর মধ্যে দেখায়, প্রান্তে ক্রসফেড ──
export const Scene: React.FC<{ from: number; to: number; fade?: number; first?: boolean; last?: boolean; children: React.ReactNode }> =
  ({ from, to, fade = 0.5, first, last, children }) => {
    const t = useCurrentFrame() / FPS;
    if (t < from - 0.01 || t > to + fade) return null;
    const inn = first ? 1 : clamp01((t - from) / fade);
    const out = last ? 1 : 1 - clamp01((t - to) / fade);
    return (
      <AbsoluteFill style={{ opacity: Math.min(inn, out) }}>
        <svg width={L.w} height={L.h} viewBox="0 0 1920 1080" style={{ position: "absolute", inset: 0 }}>{children}</svg>
      </AbsoluteFill>
    );
  };

// ── ধাপ-ট্যাব বার ──
const TABS = ["১ · মা বাঁচানো", "২ · বাচ্চা বাঁচানো", "৩ · নদী বাঁচানো"];
export const TabBar: React.FC<{ show: [number, number]; switches: [number, number] }> = ({ show, switches }) => {
  const t = useCurrentFrame() / FPS;
  const vis = clamp01((t - show[0]) / 0.4) * (1 - clamp01((t - show[1]) / 0.4));
  if (vis <= 0) return null;
  const active = t >= switches[1] ? 2 : t >= switches[0] ? 1 : 0;
  const h = L.tab.h;
  return (
    <div style={{ position: "absolute", left: 0, right: 0, top: L.tab.y, display: "flex", justifyContent: "center", gap: 14, opacity: vis, transform: `translateY(${(1 - vis) * -14}px)` }}>
      {TABS.map((s, i) => {
        const on = i === active, done = i < active;
        return (
          <div key={i} style={{ height: h, padding: "0 34px", display: "flex", alignItems: "center", gap: 12, borderRadius: h / 2, fontFamily: FONT, fontWeight: 700, fontSize: 30,
            background: on ? T.accent : T.surfaceHi, color: on ? T.onAccent : T.muted, border: `2px solid ${on ? T.accent : T.border}`,
            boxShadow: on ? `0 0 22px ${T.accent}66` : "none" }}>
            {done && <span style={{ width: 12, height: 12, borderRadius: 6, background: T.good }} />}
            {s}
          </div>
        );
      })}
    </div>
  );
};

// ── ক্যাপশন: শব্দে-শব্দে হাইলাইট, নির্দিষ্ট জায়গায় ──
const chunks = chunkWords(timing.words, { maxWords: 3, maxChars: 24, gap: 0.45 });
export const Caption: React.FC = () => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  const st = captionState(chunks, t);
  if (!st) return null;
  const enter = interpolate(t - st.chunk.start, [0, 0.12], [0, 1], { extrapolateRight: "clamp" });
  return (
    <div style={{ position: "absolute", left: 0, right: 0, top: L.caption.y, height: 0, display: "flex", justifyContent: "center", alignItems: "center", opacity: enter }}>
      <div style={{ display: "flex", gap: 12, padding: "12px 26px", borderRadius: 30, background: T.surfaceHi, border: `1.5px solid ${T.border}`, fontFamily: FONT, fontWeight: 700, fontSize: L.caption.font, lineHeight: 1.15, whiteSpace: "nowrap", boxShadow: "0 8px 30px rgba(0,0,0,0.35)" }}>
        {st.chunk.words.map((w: { w: string }, k: number) => {
          const on = k === st.active, done = k < st.active;
          return <span key={k} style={{ padding: "4px 14px", borderRadius: 14, background: on ? T.accent : "transparent", color: on ? T.onAccent : done ? T.text : T.muted, opacity: on || done ? 1 : 0.5 }}>{w.w}</span>;
        })}
      </div>
    </div>
  );
};
