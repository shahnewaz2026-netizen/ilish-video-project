import React from "react";
import { theme as T, FONT } from "../theme";
import { glen } from "../helpers.mjs";

const C = (p: number) => Math.min(1, Math.max(0, p));

// চিপ (লেবেল): কেন্দ্র (x,y)
export const Chip: React.FC<{ x: number; y: number; text: string; p?: number; tone?: string; size?: number; solid?: boolean }> =
  ({ x, y, text, p = 1, tone = T.data, size = 34, solid = false }) => {
    const w = glen(text) * size * 0.58 + 54, h = size + 34;
    return (
      <g transform={`translate(${x} ${y + (1 - C(p)) * 18}) scale(${0.9 + 0.1 * C(p)})`} opacity={C(p)}>
        <rect x={-w / 2} y={-h / 2} width={w} height={h} rx={h / 2} fill={solid ? tone : T.surface} stroke={tone} strokeWidth={2.5} style={{ filter: `drop-shadow(0 0 10px ${tone}55)` }} />
        <text x={0} y={size * 0.34} textAnchor="middle" fontFamily={FONT} fontWeight={700} fontSize={size} fill={solid ? T.onAccent : tone}>{text}</text>
      </g>
    );
  };

// ✕ চিহ্ন (ধারাবাহিক আঁকা)
export const XMark: React.FC<{ x: number; y: number; size?: number; p?: number; tone?: string }> = ({ x, y, size = 40, p = 1, tone = T.bad }) => {
  const a = C(p * 2), b = C(p * 2 - 1), s = size;
  return (
    <g transform={`translate(${x} ${y}) scale(${0.85 + 0.15 * C(p)})`} opacity={p > 0 ? 1 : 0} style={{ filter: `drop-shadow(0 0 8px ${tone})` }}>
      <line x1={-s} y1={-s} x2={-s + 2 * s * a} y2={-s + 2 * s * a} stroke={tone} strokeWidth={10} strokeLinecap="round" />
      <line x1={s} y1={-s} x2={s - 2 * s * b} y2={-s + 2 * s * b} stroke={tone} strokeWidth={10} strokeLinecap="round" />
    </g>
  );
};
export const Check: React.FC<{ x: number; y: number; size?: number; p?: number; tone?: string }> = ({ x, y, size = 36, p = 1, tone = T.good }) => (
  <g transform={`translate(${x} ${y}) scale(${0.85 + 0.15 * C(p)})`} opacity={p > 0 ? 1 : 0} style={{ filter: `drop-shadow(0 0 8px ${tone})` }}>
    <path d={`M ${-size} 0 L ${-size * 0.3} ${size * 0.7} L ${size} ${-size * 0.7}`} fill="none" stroke={tone} strokeWidth={11} strokeLinecap="round" strokeLinejoin="round" strokeDasharray={200} strokeDashoffset={200 * (1 - C(p))} />
  </g>
);

// স্ট্যাম্প
export const Stamp: React.FC<{ x: number; y: number; text: string; p?: number; tone?: string; rot?: number; size?: number }> = ({ x, y, text, p = 1, tone = T.bad, rot = -4, size = 44 }) => {
  const w = glen(text) * size * 0.6 + 56, h = size + 36, sc = 1.5 - 0.5 * C(p);
  return (
    <g transform={`translate(${x} ${y}) rotate(${rot}) scale(${sc})`} opacity={C(p * 1.5)} style={{ filter: `drop-shadow(0 0 12px ${tone}88)` }}>
      <rect x={-w / 2} y={-h / 2} width={w} height={h} rx={12} fill={`${T.bg}CC`} stroke={tone} strokeWidth={5} />
      <text x={0} y={size * 0.34} textAnchor="middle" fontFamily={FONT} fontWeight={700} fontSize={size} fill={tone}>{text}</text>
    </g>
  );
};

// বড় সংখ্যা কার্ড
export const NumCard: React.FC<{ x: number; y: number; num: string; unit?: string; p?: number; tone?: string; w?: number; h?: number; numSize?: number }> =
  ({ x, y, num, unit, p = 1, tone = T.data, w = 280, h = 140, numSize = 80 }) => (
    <g transform={`translate(${x} ${y + (1 - C(p)) * 24}) scale(${0.92 + 0.08 * C(p)})`} opacity={C(p)}>
      <rect x={-w / 2} y={-h / 2} width={w} height={h} rx={24} fill={T.surface} stroke={tone} strokeWidth={3} style={{ filter: `drop-shadow(0 0 14px ${tone}66)` }} />
      <text x={unit ? -18 : 0} y={numSize * 0.34} textAnchor="middle" fontFamily={FONT} fontWeight={700} fontSize={numSize} fill={tone}>{num}</text>
      {unit && <text x={w / 2 - 28} y={numSize * 0.34} textAnchor="end" fontFamily={FONT} fontWeight={600} fontSize={32} fill={T.muted}>{unit}</text>}
    </g>
  );

// প্রগ্রেস বার (x = বাঁ প্রান্ত)
export const Bar: React.FC<{ x: number; y: number; w: number; v: number; tone?: string; h?: number }> = ({ x, y, w, v, tone = T.data, h = 26 }) => (
  <g>
    <rect x={x} y={y} width={w} height={h} rx={h / 2} fill={T.surfaceHi} stroke={T.border} strokeWidth={1.5} />
    <rect x={x} y={y} width={Math.max(h, w * C(v))} height={h} rx={h / 2} fill={tone} />
  </g>
);

// তীর: from→to, p = আঁকা
export const Arrow: React.FC<{ x1: number; y1: number; x2: number; y2: number; p?: number; tone?: string; w?: number }> = ({ x1, y1, x2, y2, p = 1, tone = T.flow, w = 5 }) => {
  const q = C(p), ex = x1 + (x2 - x1) * q, ey = y1 + (y2 - y1) * q, ang = Math.atan2(y2 - y1, x2 - x1);
  return (
    <g opacity={q > 0 ? 1 : 0}>
      <line x1={x1} y1={y1} x2={ex} y2={ey} stroke={tone} strokeWidth={w} strokeLinecap="round" />
      <path d="M 0 0 L -22 -12 L -22 12 Z" fill={tone} transform={`translate(${ex} ${ey}) rotate(${(ang * 180) / Math.PI})`} />
    </g>
  );
};

// গোল নম্বর-ব্যাজ
export const Badge: React.FC<{ x: number; y: number; n: string; tone?: string; p?: number }> = ({ x, y, n, tone = T.accent, p = 1 }) => (
  <g transform={`translate(${x} ${y}) scale(${0.8 + 0.2 * C(p)})`} opacity={C(p)}>
    <circle r={30} fill={tone} />
    <text x={0} y={12} textAnchor="middle" fontFamily={FONT} fontWeight={700} fontSize={36} fill={T.onAccent}>{n}</text>
  </g>
);

// স্টেজ-লেবেল (ট্যাবের নিচের শিরোনাম)
export const StageLabel: React.FC<{ text: string; y: number; p?: number }> = ({ text, y, p = 1 }) => (
  <text x={960} y={y} textAnchor="middle" fontFamily={FONT} fontWeight={700} fontSize={44} fill={T.accent} opacity={C(p)}>{text}</text>
);
