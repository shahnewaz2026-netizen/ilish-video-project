const seg = new Intl.Segmenter("bn", { granularity: "grapheme" });
export const glen = (s) => [...seg.segment(s)].length;

export function chunkWords(words, { maxWords = 3, maxChars = 24, gap = 0.45 } = {}) {
  const chunks = []; let cur = [];
  const flush = () => { if (cur.length) { chunks.push(cur); cur = []; } };
  for (const w of words) {
    const chars = glen([...cur, w].map((x) => x.w).join(" "));
    if (cur.length && (cur.length >= maxWords || chars > maxChars)) flush();
    if (cur.length && w.s - cur[cur.length - 1].e > gap) flush();
    cur.push(w);
    if (/[।,?!;:—]$/.test(w.w)) flush();
  }
  flush();
  return chunks.map((c) => ({ words: c, start: c[0].s, end: c[c.length - 1].e }));
}

export function captionState(chunks, t, hold = 0.35) {
  for (let i = 0; i < chunks.length; i++) {
    const c = chunks[i], next = chunks[i + 1];
    const until = next ? Math.min(next.start, c.end + hold) : c.end + hold;
    if (t >= c.start - 0.02 && t < until) {
      let active = -1;
      c.words.forEach((w, k) => { if (t >= w.s) active = k; });
      return { chunk: c, active };
    }
  }
  return null;
}

export const countAt = (t, startSec, durSec, from, to) => {
  const p = Math.min(1, Math.max(0, (t - startSec) / durSec));
  return Math.round(from + (to - from) * (1 - Math.pow(1 - p, 3)));
};
export const toBn = (n) => String(n).replace(/\d/g, (d) => "০১২৩৪৫৬৭৮৯"[d]);

const tc = (h, m, s, ms) => +h * 3600 + +m * 60 + +s + +ms.padEnd(3, "0") / 1000;
export function parseSrt(text) {
  const t = text.replace(/^\uFEFF/, "").replace(/\r/g, "").trim();
  const cues = [];
  for (const block of t.split(/\n{2,}/)) {
    const lines = block.split("\n").map((l) => l.trim()).filter(Boolean);
    const i = lines.findIndex((l) => /-->/.test(l));
    if (i < 0) continue;
    const m = lines[i].match(/(\d+):(\d+):(\d+)[,.](\d+)\s*-->\s*(\d+):(\d+):(\d+)[,.](\d+)/);
    if (!m) continue;
    const txt = lines.slice(i + 1).join(" ").replace(/<[^>]+>/g, "").replace(/\{[^}]*\}/g, "").replace(/\s+/g, " ").trim();
    if (!txt) continue;
    cues.push({ s: tc(m[1], m[2], m[3], m[4]), e: tc(m[5], m[6], m[7], m[8]), text: txt });
  }
  cues.sort((a, b) => a.s - b.s);
  for (let k = 0; k < cues.length - 1; k++) if (cues[k].e > cues[k + 1].s) cues[k].e = cues[k + 1].s;
  return cues.filter((c) => c.e > c.s);
}

export function distributeWords(cues) {
  const words = [];
  for (const c of cues) {
    const ws = c.text.split(" ").filter(Boolean);
    const total = ws.reduce((a, w) => a + glen(w), 0) || 1;
    let t = c.s;
    for (const w of ws) {
      const d = ((c.e - c.s) * glen(w)) / total;
      words.push({ w, s: +t.toFixed(3), e: +(t + d).toFixed(3) });
      t += d;
    }
  }
  return words;
}
