import timing from "./timing.json";

const norm = (w: string) => w.replace(/[।,?!;:]/g, "");
// at(cue, "শব্দ") → ওই cue-র শব্দের শুরুর সেকেন্ড। শেষে * দিলে prefix-মিল। nth = কতজন্ম মিল
export function at(cue: number, word: string, nth = 0, off = 0): number {
  const c = timing.cues[cue - 1];
  const star = word.endsWith("*");
  const key = star ? word.slice(0, -1) : word;
  const hits = c.words.filter((w) => (star ? norm(w.w).startsWith(key) : norm(w.w) === key));
  if (!hits[nth]) throw new Error(`cue ${cue}: শব্দ পাওয়া গেল না "${word}"`);
  return hits[nth].s + off;
}
export const cs = (n: number) => timing.cues[n - 1].s;
export const ce = (n: number) => timing.cues[n - 1].e;
export const AUDIO_SEC = timing.audioSec;
export const TOTAL_FRAMES = Math.ceil((AUDIO_SEC + 1.0) * 30);
