import React from "react";
import { Composition } from "remotion";
import { Main } from "./Main";
import { L } from "./layout";
import { TOTAL_FRAMES } from "./cues";

export const Root: React.FC = () => (
  <Composition id="Main" component={Main} width={L.w} height={L.h} fps={30} durationInFrames={TOTAL_FRAMES} />
);
