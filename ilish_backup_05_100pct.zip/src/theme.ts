// নদী-নীল থিম (ব্যবহারকারীর বাছা): গাঢ় নীল-নেভি ব্যাকগ্রাউন্ড, রুপালি-সাদা হাইলাইট
export const theme = {
  bg: "#0A1F3D", surface: "#12305A", surfaceHi: "#1A3E70", border: "#2E5A94",
  text: "#EAF3FF", muted: "#8FA9C9",
  accent: "#E3EEF9", onAccent: "#0A1F3D",
  data: "#5FB6FF", flow: "#7FD1FF",
  good: "#4FD39A", bad: "#FF6B6B", warn: "#FFC857",
  // ইলাস্ট্রেশন
  line: "#06152B", fish: "#C9D6E3", fishHi: "#F2F7FC", fishBack: "#7C93B0",
  river: "#2B7BC4", riverDeep: "#1E5FA3", sea: "#17508F", seaDeep: "#0F3F75",
  salt: "#E8C26A", land: "#2C4A72", landHi: "#3E6191",
  skin: "#E7B48C", cloth: "#F2A65A", cloth2: "#7FD1FF", hair: "#2A1E1A", wood: "#A8744A", woodDeep: "#7C5233",
} as const;
export type Theme = typeof theme;
export const FONT = "HindSiliguri, 'Hind Siliguri', sans-serif";
