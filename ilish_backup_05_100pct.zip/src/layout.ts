// অনুপাত এক জায়গায়: RATIO বদলালে Composition-এর মাপ, ক্যাপশন ও ট্যাব বদলায়
export const RATIOS = {
  "9:16": { w: 1080, h: 1920, margin: 70, tab: { y: 150, h: 62 }, label: { y: 262 }, stage: { top: 280, bottom: 1300 }, caption: { y: 1398, font: 62, pillH: 115 }, reserveFrom: 1500, k: 1, glowR: 700 },
  "16:9": { w: 1920, h: 1080, margin: 100, tab: { y: 44, h: 56 }, label: { y: 128 }, stage: { top: 160, bottom: 850 }, caption: { y: 940, font: 52, pillH: 100 }, reserveFrom: 1000, k: 0.7, glowR: 850 },
} as const;
export type RatioKey = keyof typeof RATIOS;
export const RATIO: RatioKey = "16:9";
export const L = RATIOS[RATIO];
export type Layout = (typeof RATIOS)[RatioKey];
export const px = (n: number) => Math.round(n * L.k);
