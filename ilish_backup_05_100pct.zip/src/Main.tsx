import React from "react";
import { AbsoluteFill, Audio, staticFile } from "remotion";
import "./fonts";
import { Bg, Scene, TabBar, Caption } from "./components/frame";
import { at, cs } from "./cues";
import { SC } from "./scenes";
import { SceneA } from "./scenes/A";
import { SceneB } from "./scenes/B";
import { SceneC } from "./scenes/C";
import { SceneD } from "./scenes/D";
import { SceneE } from "./scenes/E";
import { SceneF } from "./scenes/F";
import { SceneG } from "./scenes/G";
import { SceneH } from "./scenes/H";
import { SceneI } from "./scenes/I";
import { SceneJ } from "./scenes/J";

export const Main: React.FC = () => (
  <AbsoluteFill>
    <Bg />
    <Scene from={SC.A[0]} to={SC.A[1]} first><SceneA /></Scene>
    <Scene from={SC.B[0]} to={SC.B[1]}><SceneB /></Scene>
    <Scene from={SC.C[0]} to={SC.C[1]}><SceneC /></Scene>
    <Scene from={SC.D[0]} to={SC.D[1]}><SceneD /></Scene>
    <Scene from={SC.E[0]} to={SC.E[1]}><SceneE /></Scene>
    <Scene from={SC.F[0]} to={SC.F[1]}><SceneF /></Scene>
    <Scene from={SC.G[0]} to={SC.G[1]}><SceneG /></Scene>
    <Scene from={SC.H[0]} to={SC.H[1]}><SceneH /></Scene>
    <Scene from={SC.I[0]} to={SC.I[1]}><SceneI /></Scene>
    <Scene from={SC.J[0]} to={SC.J[1]} last><SceneJ /></Scene>
    <TabBar show={[cs(7), cs(22)]} switches={[at(14, "দ্বিতীয়") - 0.1, cs(18)]} />
    <Caption />
    <Audio src={staticFile("voice.mp3")} />
  </AbsoluteFill>
);
