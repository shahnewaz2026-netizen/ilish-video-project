// inputs/corrected.srt থেকে src/timing.json বানায় (ASR ছাড়া: cue-র ভেতরে শব্দ-সময় গ্রাফিম-অনুপাতে)
import fs from "node:fs";
import { parseSrt, distributeWords } from "../src/helpers.mjs";

const cues = parseSrt(fs.readFileSync(new URL("../inputs/corrected.srt", import.meta.url), "utf8"));
const out = cues.map((c, i) => {
  const words = distributeWords([c]);
  return { n: i + 1, s: c.s, e: c.e, text: c.text, words };
});
const words = out.flatMap((c) => c.words);
fs.writeFileSync(new URL("../src/timing.json", import.meta.url), JSON.stringify({ audioSec: 119.56, cues: out, words }, null, 1));
console.log("cues", out.length, "words", words.length);
